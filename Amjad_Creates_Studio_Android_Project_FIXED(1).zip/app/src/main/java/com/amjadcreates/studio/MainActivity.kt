package com.amjadcreates.studio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class VideoItem(val page:String,val number:Int,val title:String,val prompt:String,val tags:String)

class MainActivity : ComponentActivity() {
    private fun loadVideos(): List<VideoItem> {
        val raw = assets.open("videos.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o: JSONObject = arr.getJSONObject(i)
            VideoItem(o.getString("page"),o.getInt("number"),o.getString("title"),o.getString("prompt"),o.getString("tags_text"))
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val videos = loadVideos()
        setContent { StudioScreen(videos) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(videos: List<VideoItem>) {
    val context = LocalContext.current
    val pages = listOf("Amjad creates","Amjad creates magic","Amjad creates kids","Amjad viral world")
    var page by remember { mutableStateOf(pages[0]) }
    var index by remember { mutableIntStateOf(0) }
    val filtered = remember(page,videos) { videos.filter { it.page == page } }
    val item = filtered[index.coerceIn(0,filtered.lastIndex)]
    fun copy(value:String, msg:String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Amjad Creates Studio",value))
        Toast.makeText(context,msg,Toast.LENGTH_SHORT).show()
    }
    MaterialTheme {
        Scaffold(topBar={ TopAppBar(title={ Text("Amjad Creates Studio") }) }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("চারটি আইডি • প্রতিটিতে ৫০টি ভিডিও", style=MaterialTheme.typography.titleMedium)
                pages.forEach { p ->
                    OutlinedButton(onClick={ page=p; index=0 }, modifier=Modifier.fillMaxWidth()) {
                        Text((if(page==p) "✓ " else "") + p + " • ৫০টি")
                    }
                }
                HorizontalDivider()
                Text("ভিডিও ${index+1} / ৫০", style=MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={index=(index+49)%50},modifier=Modifier.weight(1f)){Text("আগের ভিডিও")}
                    Button(onClick={index=(index+1)%50},modifier=Modifier.weight(1f)){Text("পরের ভিডিও")}
                }
                Text(item.title,style=MaterialTheme.typography.titleLarge)
                Text("Google Flow ভিডিও প্রম্পট",style=MaterialTheme.typography.titleMedium)
                Text(item.prompt)
                Button(onClick={copy(item.prompt,"প্রম্পট কপি হয়েছে")},modifier=Modifier.fillMaxWidth()){Text("প্রম্পট কপি করুন")}
                HorizontalDivider()
                Text("বাংলা টাইটেল",style=MaterialTheme.typography.titleMedium)
                Text(item.title)
                OutlinedButton(onClick={copy(item.title,"টাইটেল কপি হয়েছে")},modifier=Modifier.fillMaxWidth()){Text("শুধু টাইটেল কপি")}
                Text("৪টি হ্যাশট্যাগ",style=MaterialTheme.typography.titleMedium)
                Text(item.tags)
                OutlinedButton(onClick={copy(item.tags,"হ্যাশট্যাগ কপি হয়েছে")},modifier=Modifier.fillMaxWidth()){Text("শুধু হ্যাশট্যাগ কপি")}
                Button(onClick={copy(item.title+"\n"+item.tags+"\n\n"+item.prompt,"সব কপি হয়েছে")},modifier=Modifier.fillMaxWidth()){Text("সব একসঙ্গে কপি করুন")}
                Text("প্রতিটি ভিডিওতে আবু বক্কর, হাবিবা, ইউসুফ ও বুশরা থাকবে। Google Flow-তে একই চারজনের রেফারেন্স ছবি ব্যবহার করুন। AI ভিডিও তৈরি হলে মুখ, পোশাক, সংলাপ ও দৃশ্য নিজে যাচাই করুন।",style=MaterialTheme.typography.bodySmall)
            }
        }
    }
}
